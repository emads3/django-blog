from django.contrib import admin
from .models import Posts,Comments

admin.site.register(Posts)
admin.site.register(Comments)