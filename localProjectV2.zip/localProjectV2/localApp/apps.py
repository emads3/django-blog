from django.apps import AppConfig


class LocalappConfig(AppConfig):
    name = 'localApp'
